/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   philo.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anrivera <anrivera@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/18 13:36:00 by anrivera          #+#    #+#             */
/*   Updated: 2025/04/15 15:43:36 by anrivera         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/philo.h"
/*
Program name philo
Turn in files Makefile, *.h, *.c, in directory philo/
Makefile NAME, all, clean, fclean, re
Arguments number_of_philosophers time_to_die time_to_eat
time_to_sleep
[number_of_times_each_philosopher_must_eat]
External functs. memset, printf, malloc, free, write,
usleep, gettimeofday, pthread_create,
pthread_detach, pthread_join, pthread_mutex_init,
pthread_mutex_destroy, pthread_mutex_lock,
pthread_mutex_unlock
Libft authorized No
Description Philosophers with threads and mutexes
*/

int	main(int argc, char *argv[])
{
	t_philo			philos[PHILO_MAX];
	t_table			table;
	pthread_mutex_t	forks[PHILO_MAX];
	int				number_of_philos;

	if (argc != 5 && argc != 6)
		return (printf("Incorrect amount of arguments"));
	if (check_arguments(argv) == 1)
		return (1);
	number_of_philos = ft_atoi(argv[1]);
	init_table(&table, philos);
	init_forks(forks, number_of_philos);
	init_philos(philos, &table, forks, argv);
	launch_thread(&table, forks);
	destroy_all(NULL, &table, forks);
	return (0);
}
