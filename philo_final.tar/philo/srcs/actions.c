/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   actions.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anrivera <anrivera@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/15 13:50:41 by anrivera          #+#    #+#             */
/*   Updated: 2025/04/15 14:21:31 by anrivera         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include	"../includes/philo.h"

void	eat(t_philo *philo)
{
	pthread_mutex_lock(philo->right_fork);
	log_message("has taken a fork", philo, philo ->id);
	if (philo ->amount_of_philos == 1)
	{
		ft_usleep(philo->time_to_die);
		pthread_mutex_unlock(philo->right_fork);
		return ;
	}
	pthread_mutex_lock(philo->left_fork);
	log_message("has taken a fork", philo, philo ->id);
	philo->is_eating = 1;
	log_message("is eating", philo, philo ->id);
	pthread_mutex_lock(philo->meal_lock);
	philo ->last_meal = get_current_time();
	philo ->meals_eaten ++;
	pthread_mutex_unlock(philo->meal_lock);
	ft_usleep(philo->time_to_eat);
	philo->is_eating = 0;
	pthread_mutex_unlock(philo->left_fork);
	pthread_mutex_unlock(philo->right_fork);
}

void	rest(t_philo *philo)
{
	log_message("is sleeping", philo, philo->id);
	ft_usleep(philo->time_to_sleep);
}

void	think(t_philo *philo)
{
	pthread_mutex_lock(philo->right_fork);
	log_message("is thinking", philo, philo->id);
}
