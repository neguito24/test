/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   threads.c                                          :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anrivera <anrivera@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/03/03 14:01:23 by anrivera          #+#    #+#             */
/*   Updated: 2025/04/08 15:11:39 by anrivera         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/philo.h"

int	monitor_death(t_philo *philo)
{
	pthread_mutex_lock(philo->dead_lock);
	if (*philo->dead == 1)
	{
		pthread_mutex_unlock(philo->dead_lock);
		return (1);
	}	
	pthread_mutex_unlock(philo->dead_lock);
	return (0);
}
void	*dine_routine(void *pointer)
{
	t_philo	*philo;

	philo = (t_philo *)pointer;
	if (philo -> id % 2 == 0)
		ft_usleep(1);
	while (!monitor_dead(philo))
	{
		eat(philo);
		rest(philo);
		think(philo);
	}
	return (pointer);
}

int	launch_thread(t_table *table, pthread_mutex_t *forks)
{
	pthread_t	controler;
	int			i;

	if (pthread_create(&controler, NULL, &check_status_table,
			table->philos) != 0)
		destroy_all("Failure to create threads", table, forks);
	i = 0;
	while (i < table->philos[0].amount_of_philos)
	{
		if (pthread_create(&table->philos[i].thread, NULL, &dine_routine,
			 &table->philos[i]) != 0)
	}
}
