/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   utils.c                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anrivera <anrivera@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/18 13:36:52 by anrivera          #+#    #+#             */
/*   Updated: 2025/03/25 16:42:53 by anrivera         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/philo.h"

int	ft_atoi(char *str)
{
	unsigned long long	nb;
	int					sign;
	int					i;

	nb = 0;
	sign = 1;
	i = 0;
	while (str[i] == ' ' || str[i] == '\t' || str[i] == '\n' || str[i] == '\v'
		|| str[i] == '\f' || str[i] == '\r')
		i++;
	if (str[i] == '-')
		sign = -1;
	if (str[i] == '-' || str[i] == '+')
		i++;
	while (str[i] >= '0' && str[i] <= '9')
	{
		nb = nb * 10 + (str[i] - '0');
		i++;
	}
	return (sign * nb);
}

int	is_digit(char *str)
{
	int	i;

	i = 0;
	while (str[i] != '\0')
	{
		if (str[i] < '0' || str[i] > '9')
			return (1);
		i++;
	}
	return (0);
}

int	check_arguments(char **argv)
{
	if (ft_atoi(argv[1]) > PHILO_MAX || ft_atoi(argv[1]) <= 0
		|| is_digit(argv[1]) == 1)
		return (printf("Invalid philosophers number\n"));
	if (ft_atoi(argv[2]) <= 0 || is_digit(argv[2]) == 1)
		return (printf("Invalid time to die\n"));
	if (ft_atoi(argv[3]) <= 0 || is_digit(argv[3]) == 1)
		return (printf("Invalid time to eat\n"));
	if (ft_atoi(argv[4]) <= 0 || is_digit(argv[4]) == 1)
		return (printf("Invalid time to sleep\n"));
	if (argv[5] && (ft_atoi(argv[5]) < 0 || is_digit(argv[5]) == 1))
		return (printf("Invalid number of times each philosopher must eat\n"));
	return (0);
}
