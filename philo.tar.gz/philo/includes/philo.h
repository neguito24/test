/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   philo.h                                            :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anrivera <anrivera@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/02/18 13:37:03 by anrivera          #+#    #+#             */
/*   Updated: 2025/03/27 17:48:12 by anrivera         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#ifndef PHILO_H
# define PHILO_H

# include <stdio.h>
# include <pthread.h>
# include <stdlib.h>

# define PHILO_MAX 300

typedef struct s_philo
{
	pthread_t		thread;
	int				id;
	int				is_eating;
	int				meals_eaten;
	size_t			last_meal;
	size_t			time_to_die;
	size_t			time_to_eat;
	size_t			time_to_sleep;
	size_t			start_time;
	int				amount_of_philos;
	int				amount_of_times_to_eat;
	int				*dead;
	pthread_mutex_t	*right_fork;
	pthread_mutex_t	*left_fork;
	pthread_mutex_t	*write_lock;
	pthread_mutex_t	*dead_lock;
	pthread_mutex_t	*meal_lock;
}	t_philo;
typedef struct s_table
{
	int					dead_status;
	pthread_mutex_t		dead_lock;
	pthread_mutex_t		meal_lock;
	pthread_mutex_t		write_lock;
	t_philo				*philos;
}	t_table;

int		ft_atoi(char *str);
int		is_digit(char *str);
int		check_arguments(char **argv);

void	init_arguments(t_philo *philo, char **argv);
void	init_table(t_table *table, t_philo *philos);
void	init_forks(pthread_mutex_t *forks, int number_philo);
void	init_philos(t_philo *philos, t_table *table, pthread_mutex_t *forks,
	char **argv );

#endif