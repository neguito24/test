/* ************************************************************************** */
/*                                                                            */
/*                                                        :::      ::::::::   */
/*   control_events.c                                   :+:      :+:    :+:   */
/*                                                    +:+ +:+         +:+     */
/*   By: anrivera <anrivera@student.42.fr>          +#+  +:+       +#+        */
/*                                                +#+#+#+#+#+   +#+           */
/*   Created: 2025/04/03 14:49:39 by anrivera          #+#    #+#             */
/*   Updated: 2025/04/04 14:48:10 by anrivera         ###   ########.fr       */
/*                                                                            */
/* ************************************************************************** */

#include "../includes/philo.h"

void	log_message(char *str, t_philo *philo, int id)
{
	size_t	time;

	pthread_mutex_lock(philo->write_lock);
	time = get_current_time() - philo->start_time;
	if (!monitor_death(philo))
		printf("%zu %d %s\n", time, id, str);
	pthread_mutex_unlock(philo->write_lock);
}

void	*check_status_table(void *p)
{
	t_philo	*philos;

	philos = (t_philo *)p;
	while (1)
	{
		if (dead_event(philos) == 1 || all_ate_event(philos) == 1)
			break;
		return (p);
	}
}

int	is_philo_dead(t_philo *philo, size_t time_to_die)
{
	pthread_mutex_lock(philo->meal_lock);
	if (get_current_time() - philo->last_meal >= time_to_die
		&& philo->is_eating == 0)
	{
		pthread_mutex_unlock(philo->meal_lock);
		return (1);
	}
	pthread_mutex_unlock(philo->meal_lock);
	return (0);
}

int	dead_event(t_philo *philos)
{
	int	i;

	i = 0;
	while (i < philos[0].amount_of_philos)
	{
		if (is_philo_dead(&philos[i], philos[i].time_to_die))
		{
			log_message("died", &philos[i], philos[i].id);
			pthread_mutex_lock(philos[0].dead_lock);
			*philos->dead = 1;
			pthread_mutex_unlock(philos[0].dead_lock);
			return (1);
		}
		i++;
	}
	return(0);
}
